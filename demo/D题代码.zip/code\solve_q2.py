﻿# -*- coding: utf-8 -*-
"""问题二：三坐标均有误差（Z 单边截尾正态），给出命中概率表达式并优化定深深度 d。"""
import json, sys, io
import numpy as np
from scipy import integrate, stats, optimize
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

with open(r"data/parameters.json", encoding="utf-8-sig") as f:
    P = json.load(f)
a, b, c = P["submarine"]["half_length"], P["submarine"]["half_width"], P["submarine"]["half_height"]
R = P["weapon"]["kill_radius"]
sigma = P["errors"]["sigma_xy"]
h0 = P["errors"]["depth_est"]
sigz = P["errors"]["sigma_z"]
l = P["errors"]["min_depth"]

phi = stats.norm.pdf
Phi = stats.norm.cdf

# ---------------- 截尾正态 Z 的 CDF ----------------
denom = 1.0 - Phi((l - h0) / sigz)          # = Phi((h0-l)/sigz) ≈ 0.7734
def F_Z(z):
    z = np.asarray(z, dtype=float)
    return np.where(z <= l, 0.0, (Phi((z - h0) / sigz) - Phi((l - h0) / sigz)) / denom)

def f_X(x): return phi(x / sigma) / sigma
def f_Y(y): return phi(y / sigma) / sigma

# ---------------- 命中逻辑（蒙特卡洛） ----------------
def hit_mask_q2(X, Y, Z, x0, y0, d):
    dx = np.abs(X - x0); dy = np.abs(Y - y0)
    in_plane = (dx <= a) & (dy <= b)
    h = np.sqrt(np.maximum(dx - a, 0) ** 2 + np.maximum(dy - b, 0) ** 2)
    v = np.maximum(Z - c - d, np.maximum(d - Z - c, 0.0))
    dist = np.sqrt(h ** 2 + v ** 2)
    hit = np.zeros_like(X, dtype=bool)
    hit |= in_plane & (Z <= d + c)                    # E1 触发引信
    hit |= in_plane & (Z > d + c) & ((Z - c - d) <= R)  # E2 定深、平面内
    hit |= (~in_plane) & (dist <= R)                  # E3 定深、平面外
    return hit

def sample_Z(rng, N):
    u = rng.uniform(0.0, 1.0, N)
    return h0 + sigz * stats.norm.ppf(Phi((l - h0) / sigz) + u * denom)

# ---------------- 精确积分 P(d) ----------------
def P_integral(d):
    # 第一项：平面内，Z <= d + c + R
    term1 = (2 * Phi(a / sigma) - 1) * (2 * Phi(b / sigma) - 1) * F_Z(d + c + R)
    # 第二项：平面外 h<=R，第一象限三分区 x4
    # B1: x∈[0,a], y∈(b,b+R], s=y-b
    def integ_B1(y, x):
        s = np.sqrt(R ** 2 - (y - b) ** 2)
        return (F_Z(d + c + s) - F_Z(d - c - s)) * f_X(x) * f_Y(y)
    IB1, _ = integrate.dblquad(integ_B1, 0.0, a, b, b + R,
                               epsabs=1e-10, epsrel=1e-9)
    # B2: x∈(a,a+R], y∈[0,b], s=x-a
    def integ_B2(y, x):
        s = np.sqrt(R ** 2 - (x - a) ** 2)
        return (F_Z(d + c + s) - F_Z(d - c - s)) * f_X(x) * f_Y(y)
    IB2, _ = integrate.dblquad(integ_B2, a, a + R, 0.0, b,
                               epsabs=1e-10, epsrel=1e-9)
    # B3: 角区，极坐标 x=a+r cosθ, y=b+r sinθ，r∈(0,R], θ∈(0,π/2]
    def integ_B3_polar(theta, r):
        x = a + r * np.cos(theta)
        y = b + r * np.sin(theta)
        s = np.sqrt(R ** 2 - r ** 2)
        return (F_Z(d + c + s) - F_Z(d - c - s)) * f_X(x) * f_Y(y) * r
    IB3, _ = integrate.dblquad(integ_B3_polar, 0.0, R, 0.0, np.pi / 2,
                               epsabs=1e-10, epsrel=1e-9)
    return term1 + 4.0 * (IB1 + IB2 + IB3), (term1, 4 * IB1, 4 * IB2, 4 * IB3)

# ---------------- 蒙特卡洛粗扫描 d ----------------
rng = np.random.default_rng(2026)
Nmc = 2_000_000
Xmc = rng.normal(0.0, sigma, Nmc)
Ymc = rng.normal(0.0, sigma, Nmc)
Zmc = sample_Z(rng, Nmc)

d_grid = np.linspace(100.0, 190.0, 37)
P_mc_grid = np.array([hit_mask_q2(Xmc, Ymc, Zmc, 0.0, 0.0, d).mean() for d in d_grid])
d_mc_best = d_grid[np.argmax(P_mc_grid)]

# ---------------- 精确优化（Brent，在粗最优附近） ----------------
lo = max(100.0, d_mc_best - 15.0)
hi = min(200.0, d_mc_best + 15.0)
def negP(d): return -P_integral(d)[0]
opt = optimize.minimize_scalar(negP, bounds=(lo, hi), method="bounded",
                               options={"xatol": 1e-6})
d_star = opt.x
P_star, comp = P_integral(d_star)

# ---------------- 验证 ----------------
Nv = 8_000_000
Xv = rng.normal(0.0, sigma, Nv)
Yv = rng.normal(0.0, sigma, Nv)
Zv = sample_Z(rng, Nv)
P_mc_star = hit_mask_q2(Xv, Yv, Zv, 0.0, 0.0, d_star).mean()

# 落点偏移验证（x0 扫描，d=d_star）
P_mc_x0 = [hit_mask_q2(Xv, Yv, Zv, x0, 0.0, d_star).mean() for x0 in (0, 30, 60, 100)]

# ---------------- 灵敏度：σz 与 l ----------------
def F_Z_g(z, sz):
    z = np.asarray(z, dtype=float)
    den = 1.0 - Phi((l - h0) / sz)
    return np.where(z <= l, 0.0, (Phi((z - h0) / sz) - Phi((l - h0) / sz)) / den)

def sample_Z_g(rng, N, sz):
    u = rng.uniform(0.0, 1.0, N)
    return h0 + sz * stats.norm.ppf(Phi((l - h0) / sz) + u * (1 - Phi((l - h0) / sz)))

sens = []
for sigz_v in (30.0, 40.0, 50.0):
    dgrid = np.linspace(110.0, 180.0, 15)
    Pmc = []
    for d in dgrid:
        Zs = sample_Z_g(rng, 500_000, sigz_v)
        Xs = rng.normal(0.0, sigma, 500_000); Ys = rng.normal(0.0, sigma, 500_000)
        Pmc.append(hit_mask_q2(Xs, Ys, Zs, 0.0, 0.0, d).mean())
    sens.append({"sigz": sigz_v, "d_best": float(dgrid[int(np.argmax(Pmc))]),
                 "P_best": float(np.max(Pmc))})

# ---------------- 输出 ----------------
res = {
    "P_expression_terms": {
        "E1_E2_plane_in": "P(D1)*F_Z(d+c+R)",
        "E3_plane_out": "int_{D2,h<=R} [F_Z(d+c+s)-F_Z(d-c-s)] f_X f_Y dxdy",
        "c": c, "R": R
    },
    "d_grid_mc": d_grid.tolist(), "P_mc_grid": P_mc_grid.tolist(),
    "d_mc_best": float(d_mc_best),
    "d_star": float(d_star), "P_star_integral": float(P_star),
    "P_star_components": {"plane_in": comp[0], "B1": comp[1], "B2": comp[2], "B3": comp[3]},
    "P_star_mc": float(P_mc_star),
    "P_mc_x0": {"x0": [0, 30, 60, 100], "p": P_mc_x0},
    "sensitivity_sigz": sens,
}
with open(r"output/q2/result_q2.json", "w", encoding="utf-8") as f:
    json.dump(res, f, ensure_ascii=False, indent=2)

print("=== 问题二结果 ===")
print(f"蒙特卡洛粗扫描最优 d = {d_mc_best:.1f}, P={P_mc_grid.max():.6f}")
print(f"精确最优 d* = {d_star:.2f} m")
print(f"P(d*) 精确积分 = {P_star:.6f}")
print(f"  平面内(触发+定深) = {comp[0]:.6f}")
print(f"  平面外 B1(X内Y带) = {comp[1]:.6f}")
print(f"  平面外 B2(X带Y内) = {comp[2]:.6f}")
print(f"  平面外 B3(角区)   = {comp[3]:.6f}")
print(f"P(d*) 蒙特卡洛(8M)  = {P_mc_star:.6f}")
print(f"落点偏移验证 (0,30,60,100) = {[f'{p:.6f}' for p in P_mc_x0]}")
print("σz 灵敏度:", [(s['sigz'], round(s['d_best'],1), round(s['P_best'],5)) for s in sens])





