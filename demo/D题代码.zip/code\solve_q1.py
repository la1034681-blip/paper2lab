﻿# -*- coding: utf-8 -*-
"""问题一：投射一枚深弹，深度定位无误差。
推导最大命中概率与 (落点, 引爆深度) 关系，给出最优方案与最大命中概率。
"""
import json, sys, io
import numpy as np
from scipy import integrate, stats
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

# ---------------- 参数 ----------------
with open(r"data/parameters.json", encoding="utf-8-sig") as f:
    P = json.load(f)
a = P["submarine"]["half_length"]      # 50 m
b = P["submarine"]["half_width"]       # 10 m
c = P["submarine"]["half_height"]      # 12.5 m
R = P["weapon"]["kill_radius"]         # 20 m
sigma = P["errors"]["sigma_xy"]        # 120 m
h0 = P["errors"]["depth_est"]          # 150 m
z_up = h0 - c   # 潜艇上表面 137.5
z_lo = h0 + c   # 潜艇下表面 162.5

phi = stats.norm.pdf
Phi = stats.norm.cdf

# ---------------- 命中逻辑（单次投弹，Z=h0 固定） ----------------
def hit_mask(X, Y, x0, y0, d):
    """给定潜艇中心位置 (X,Y)（深度固定 h0），判断深弹 (x0,y0,d) 是否命中。"""
    dx = np.abs(X - x0); dy = np.abs(Y - y0)
    in_plane = (dx <= a) & (dy <= b)
    h = np.sqrt(np.maximum(dx - a, 0) ** 2 + np.maximum(dy - b, 0) ** 2)
    v = np.maximum(z_up - d, np.maximum(d - z_lo, 0.0))
    dist = np.sqrt(h ** 2 + v ** 2)
    hit = np.zeros_like(X, dtype=bool)
    hit |= in_plane & (d >= z_up)                    # 情形1：触发引信
    hit |= in_plane & (d < z_up) & ((z_up - d) <= R) # 情形2：定深、平面内
    hit |= (~in_plane) & (dist <= R)                 # 情形3：定深、平面外
    return hit

# ---------------- 闭式表达式 ----------------
# 平面内命中概率（原点投弹）
p_in = (2 * Phi(a / sigma) - 1) * (2 * Phi(b / sigma) - 1)

# P(B) = P( max(|X|-a,0)^2 + max(|Y|-b,0)^2 <= R^2 )，即触发区∪定深平面外区（d∈[z_up,z_lo]时）
# 第一象限数值积分：x∈[0,a+R], y∈[0,b+R]
def integrand(y, x):
    if (max(x - a, 0.0)) ** 2 + (max(y - b, 0.0)) ** 2 <= R ** 2:
        return phi(x / sigma) / sigma * phi(y / sigma) / sigma
    return 0.0

pB, pB_err = integrate.dblquad(integrand, 0.0, a + R,
                               lambda x: 0.0, lambda x: b + R, epsabs=1e-12, epsrel=1e-12)
pB *= 4.0

# 角区（平面外、带状之外、四分之一圆）单独分解（供论文表格）
# 区域分解：
#   B1 = [-a,a]x[-b-R,b+R]        平面内 X + Y 外扩带
#   B2 = [-a-R,a+R]x[-b,b]        X 外扩带 + 平面内 Y
#   B0 = B1∩B2 = 平面内
#   B3 = 角区
pB1 = (2 * Phi(a / sigma) - 1) * (2 * Phi((b + R) / sigma) - 1)
pB2 = (2 * Phi((a + R) / sigma) - 1) * (2 * Phi(b / sigma) - 1)
pB0 = p_in
# 角区：第一象限 x∈(a,a+R], y∈(b,b+R], 圆约束
def integrand_corner(y, x):
    if (x - a) ** 2 + (y - b) ** 2 <= R ** 2:
        return phi(x / sigma) / sigma * phi(y / sigma) / sigma
    return 0.0
pB3, _ = integrate.dblquad(integrand_corner, a, a + R,
                           lambda x: b, lambda x: b + np.sqrt(R ** 2 - (x - a) ** 2),
                           epsabs=1e-12, epsrel=1e-12)
pB3 *= 4.0
pB_decomp = pB1 + pB2 - pB0 + pB3

# ---------------- 蒙特卡洛验证（原点投弹） ----------------
rng = np.random.default_rng(2026)
N = 8_000_000
X = rng.normal(0.0, sigma, N)
Y = rng.normal(0.0, sigma, N)
h = np.sqrt(np.maximum(np.abs(X) - a, 0) ** 2 + np.maximum(np.abs(Y) - b, 0) ** 2)

# 直接蒙特卡洛：d 取在 [z_up, z_lo] 内（v=0）
mc_d150 = hit_mask(X, Y, 0.0, 0.0, h0).mean()
# P(B) 蒙特卡洛
mc_pB = (h <= R).mean()
# 平面内
mc_pin = ((np.abs(X) <= a) & (np.abs(Y) <= b)).mean()

# ---------------- d 敏感性（扫描 d，蒙特卡洛估计命中概率） ----------------
d_grid = np.linspace(90.0, 200.0, 23)
p_d = np.array([hit_mask(X, Y, 0.0, 0.0, d).mean() for d in d_grid])
d_opt = d_grid[np.argmax(p_d)]

# ---------------- 落点 x0 敏感性（d=150 固定） ----------------
x0_grid = np.linspace(0.0, 100.0, 11)
p_x0 = np.array([hit_mask(X, Y, x0, 0.0, h0).mean() for x0 in x0_grid])

# ---------------- 结果输出 ----------------
res = {
    "P_in_plane": p_in,                      # 仅触发引信（平面内）
    "P_max_analytic": pB,                    # 最优命中概率（数值积分）
    "P_max_analytic_decomp": pB_decomp,
    "P_max_analytic_err": pB_err,
    "MC_hit_d150": mc_d150,
    "MC_PB": mc_pB,
    "MC_pin": mc_pin,
    "P_B1": pB1, "P_B2": pB2, "P_B0": pB0, "P_B3": pB3,
    "d_opt_interval": [z_up, z_lo],
    "d_sensitivity": {"d": d_grid.tolist(), "p": p_d.tolist()},
    "x0_sensitivity": {"x0": x0_grid.tolist(), "p": p_x0.tolist()},
    "opt_scheme": {"x0": 0.0, "y0": 0.0, "d": h0},
}
with open(r"output/q1/result_q1.json", "w", encoding="utf-8") as f:
    json.dump(res, f, ensure_ascii=False, indent=2)

print("=== 问题一结果 ===")
print(f"平面内概率 P(D1)            = {p_in:.6f}")
print(f"最大命中概率 P* (数值积分)   = {pB:.6f}  (err={pB_err:.2e})")
print(f"P* 分解验证 (B1+B2-B0+B3)   = {pB_decomp:.6f}")
print(f"  其中 B1=平面内X×Y外扩带   = {pB1:.6f}")
print(f"       B2=X外扩带×平面内Y   = {pB2:.6f}")
print(f"       B0=平面内            = {pB0:.6f}")
print(f"       B3=角区(四分之一圆)  = {pB3:.6f}")
print(f"蒙特卡洛: d=150 命中概率      = {mc_d150:.6f}")
print(f"蒙特卡洛: P(h<=R)            = {mc_pB:.6f}")
print(f"蒙特卡洛: 平面内             = {mc_pin:.6f}")
print(f"最优引爆深度区间 d*          = [{z_up}, {z_lo}] m")
print(f"扫描确认最优 d (格点)        = {d_opt:.1f} m, P={p_d.max():.6f}")
print(f"落点扫描: x0=0 最优 P        = {p_x0[0]:.6f}; x0=100 时 P={p_x0[-1]:.6f}")

