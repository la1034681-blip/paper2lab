﻿# -*- coding: utf-8 -*-
"""数据一致性验证：论文文本数值 vs output/*/result_*.json（对照 E 题 verify 脚本）"""
import json, os
from docx import Document

BASE = r"C:\Users\lijiahui\Desktop\D题作答"
DOCX = os.path.join(BASE, "paper", "D题论文.docx")

doc = Document(DOCX)
full = "\n".join(p.text for p in doc.paragraphs)
for t in doc.tables:
    for row in t.rows:
        for cell in row.cells:
            full += "\n" + cell.text

q1 = json.load(open(os.path.join(BASE, "output", "q1", "result_q1.json"), encoding="utf-8"))
q2 = json.load(open(os.path.join(BASE, "output", "q2", "result_q2.json"), encoding="utf-8"))
q3 = json.load(open(os.path.join(BASE, "output", "q3", "result_q3.json"), encoding="utf-8"))
sens = json.load(open(os.path.join(BASE, "output", "q3", "sensitivity_results.json"), encoding="utf-8"))

checks = [
    ("问题一 P* = 0.0837", "0.0837", q1["P_max_analytic"], 1e-4),
    ("问题一 最优区间下界 137.5", "137.5", q1["d_opt_interval"][0], 1e-4),
    ("问题一 最优区间上界 162.5", "162.5", q1["d_opt_interval"][1], 1e-4),
    ("问题二 d* = 157.84", "157.84", q2["d_star"], 5e-3),
    ("问题二 P* = 0.0576", "0.0576", q2["P_star_integral"], 1e-4),
    ("问题三 d* = 158.75", "158.75", q3["opt"]["d"], 1e-4),
    ("问题三 间隔 Δ* = 85", "85.00", q3["opt"]["delta"], 5e-3),
    ("问题三 航向角 θ* = 45", "45", q3["opt"]["theta_deg"], 1e-4),
    ("问题三 P_any = 0.3632", "0.3632", q3["opt"]["P_joint"], 1e-4),
    ("问题三 独立近似 0.3237", "0.3237", q3["opt"]["P_independent_approx"], 1e-4),
    ("表5 Δ=85 最优 0.3630", "0.3630", sens["table5_delta_sensitivity"][2]["P"], 5e-4),
    ("表7 σ=60 0.2821", "0.2821", sens["table7_sigmaR"][0]["P"], 5e-4),
    ("表8 σz=20 d*=152.26", "152.26", sens["table8_sigz"][0]["d_star"], 1e-2),
    ("表8 σz=60 d*=168.27", "168.27", sens["table8_sigz"][4]["d_star"], 1e-2),
    ("4×4 方阵 ≈0.5028", "0.5028", sens["array_ext"]["p44"], 5e-4),
    ("相关性 32 对负相关", "32", sens["correlation"]["negative"], 0),
]

all_ok = True
print("=" * 70)
print("数据一致性验证报告（论文 docx vs output/*/result_*.json）")
print("=" * 70)
for label, needle, value, tol in checks:
    if needle not in full:
        all_ok = False
        print(f"[FAIL] 论文中未找到文本「{needle}」  ({label})")
        continue
    idx = full.index(needle)
    ctx = full[max(0, idx-30): idx+30].replace("\n", " ")
    print(f"[OK]   {label}")
    print(f"      论文上下文: ...{ctx}...")
    print(f"      JSON 值: {value!r}  容差 {tol}")
    print()
print("结论:", "全部通过" if all_ok else "存在未通过项")
