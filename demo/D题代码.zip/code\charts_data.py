﻿# -*- coding: utf-8 -*-
"""补充图表数据：Q2 P(d) 曲线、Q3 θ 扫描曲线、Q3 二维精扫描。"""
import json, sys, io
import numpy as np
from scipy import stats
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

with open(r"data/parameters.json", encoding="utf-8-sig") as f:
    P = json.load(f)
a, b, c = P["submarine"]["half_length"], P["submarine"]["half_width"], P["submarine"]["half_height"]
R = P["weapon"]["kill_radius"]
sigma = P["errors"]["sigma_xy"]; h0 = P["errors"]["depth_est"]
sigz = P["errors"]["sigma_z"]; l = P["errors"]["min_depth"]
Phi = stats.norm.cdf
denom = 1.0 - Phi((l - h0) / sigz)

def sample_XYZ(rng, N):
    X = rng.normal(0.0, sigma, N)
    Y = rng.normal(0.0, sigma, N)
    u = rng.uniform(0.0, 1.0, N)
    Z = h0 + sigz * stats.norm.ppf(Phi((l - h0) / sigz) + u * denom)
    return X, Y, Z

def hit_single(X, Y, Z, x0, y0, d):
    dx = np.abs(X - x0); dy = np.abs(Y - y0)
    in_plane = (dx <= a) & (dy <= b)
    h = np.sqrt(np.maximum(dx - a, 0) ** 2 + np.maximum(dy - b, 0) ** 2)
    v = np.maximum(Z - c - d, np.maximum(d - Z - c, 0.0))
    dist = np.sqrt(h ** 2 + v ** 2)
    hit = in_plane & (Z <= d + c)
    hit |= in_plane & (Z > d + c) & ((Z - c - d) <= R)
    hit |= (~in_plane) & (dist <= R)
    return hit

def array_points(delta, theta_deg):
    th = np.deg2rad(theta_deg)
    off = np.array([-delta, 0.0, delta])
    pts = []
    for i in off:
        for j in off:
            xr = i * np.cos(th) - j * np.sin(th)
            yr = i * np.sin(th) + j * np.cos(th)
            pts.append((xr, yr))
    return pts

def prob_any(X, Y, Z, pts, d):
    any_hit = np.zeros_like(X, dtype=bool)
    for (x0, y0) in pts:
        any_hit |= hit_single(X, Y, Z, x0, y0, d)
    return any_hit.mean()

rng = np.random.default_rng(7)

# ---- Q2: P(d) 曲线（41 点，3M 样本） ----
N2 = 3_000_000
X2, Y2, Z2 = sample_XYZ(rng, N2)
d_curve = np.linspace(120.0, 190.0, 41)
P_curve = [hit_single(X2, Y2, Z2, 0.0, 0.0, d).mean() for d in d_curve]
# 成分分解：平面内 vs 平面外（d=d* 处，用大样本）
Nc = 8_000_000
Xc, Yc, Zc = sample_XYZ(rng, Nc)
d_star_q2 = 157.84
h = np.sqrt(np.maximum(np.abs(Xc) - a, 0) ** 2 + np.maximum(np.abs(Yc) - b, 0) ** 2)
v = np.maximum(Zc - c - d_star_q2, np.maximum(d_star_q2 - Zc - c, 0.0))
dist = np.sqrt(h ** 2 + v ** 2)
inp = (np.abs(Xc) <= a) & (np.abs(Yc) <= b)
E1 = inp & (Zc <= d_star_q2 + c)
E2 = inp & (Zc > d_star_q2 + c) & ((Zc - c - d_star_q2) <= R)
E3 = (~inp) & (dist <= R)
comp = {"E1": float(E1.mean()), "E2": float(E2.mean()), "E3": float(E3.mean()),
        "total": float((E1 | E2 | E3).mean())}

# ---- Q3: θ 扫描（0-45 步长 5°，3M 样本，固定 d*,Δ* 附近） ----
q3o = json.load(open(r"output/q3/result_q3.json", encoding="utf-8-sig"))["opt"]
d3, dl3 = q3o["d"], q3o["delta"]
N3 = 3_000_000
X3, Y3, Z3 = sample_XYZ(rng, N3)
theta_grid = np.arange(0.0, 50.0, 5.0)
P_theta = [prob_any(X3, Y3, Z3, array_points(dl3, t), d3) for t in theta_grid]

# ---- Q3: (d, Δ) 精扫描（θ=45°），10x10 网格 x 2M ----
N4 = 2_000_000
X4, Y4, Z4 = sample_XYZ(rng, N4)
d4 = np.linspace(145.0, 172.0, 11)
dl4 = np.linspace(70.0, 105.0, 11)
P4 = np.zeros((len(d4), len(dl4)))
for i, dd in enumerate(d4):
    for j, dll in enumerate(dl4):
        P4[i, j] = prob_any(X4, Y4, Z4, array_points(dll, 45.0), dd)

out = {
    "q2_P_curve": {"d": d_curve.tolist(), "P": P_curve, "d_star": d_star_q2,
                   "components": comp},
    "q3_theta_curve": {"theta": theta_grid.tolist(), "P": P_theta},
    "q3_fine45": {"d": d4.tolist(), "delta": dl4.tolist(), "P": P4.tolist()},
}
with open(r"data/chart_data.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print("Q2 curve: max P =", max(P_curve), "at d =", d_curve[int(np.argmax(P_curve))])
print("Q2 comp:", {k: round(v, 5) for k, v in comp.items()})
print("Q3 theta:", [(t, round(p, 4)) for t, p in zip(theta_grid, P_theta)])
i0, j0 = np.unravel_index(np.argmax(P4), P4.shape)
print("Q3 fine45 max:", P4.max(), "at d =", d4[i0], "delta =", dl4[j0])
print("saved chart_data.json")
