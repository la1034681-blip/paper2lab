﻿# -*- coding: utf-8 -*-
"""问题三：9 枚深弹 3×3 方阵，同深度 d，间隔 Δ，朝向 θ，最大化至少一枚命中概率。
对每个朝向角 θ∈{0,15,30,45} 在 (d,Δ) 平面上做完整二维分层网格搜索（粗扫描+精扫描），
比较各朝向局部最优取全局最优，再以大样本验证；多弹命中事件对同一潜艇位置条件相关，
须对潜艇位置积分求并集概率。
"""
import json, sys, io, time
import numpy as np
from scipy import stats
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

with open(r"data/parameters.json", encoding="utf-8-sig") as f:
    P = json.load(f)
a, b, c = P["submarine"]["half_length"], P["submarine"]["half_width"], P["submarine"]["half_height"]
R = P["weapon"]["kill_radius"]
sigma = P["errors"]["sigma_xy"]; h0 = P["errors"]["depth_est"]
sigz = P["errors"]["sigma_z"]; l = P["errors"]["min_depth"]

phi = stats.norm.pdf; Phi = stats.norm.cdf
denom = 1.0 - Phi((l - h0) / sigz)

def sample_XYZ(rng, N):
    X = rng.normal(0.0, sigma, N)
    Y = rng.normal(0.0, sigma, N)
    u = rng.uniform(0.0, 1.0, N)
    Z = h0 + sigz * stats.norm.ppf(Phi((l - h0) / sigz) + u * denom)
    return X, Y, Z

def array_points(delta, theta_deg):
    """3×3 方阵落点（中心在原点），绕 Z 轴旋转 theta，返回 x/y 向量。"""
    th = np.deg2rad(theta_deg)
    off = np.array([-delta, 0.0, delta])
    xs, ys = np.meshgrid(off, off)
    xr = xs * np.cos(th) - ys * np.sin(th)
    yr = xs * np.sin(th) + ys * np.cos(th)
    return xr.ravel(), yr.ravel()

def prob_any_hit(X, Y, Z, px, py, d, chunk=1_000_000):
    """向量化计算“至少一枚命中”频率（分块控制内存）。"""
    n = len(X); total = 0
    for s in range(0, n, chunk):
        e = min(s + chunk, n)
        Xs = X[s:e]; Ys = Y[s:e]; Zs = Z[s:e]
        dx = np.abs(Xs[:, None] - px[None, :]); dy = np.abs(Ys[:, None] - py[None, :])
        in_plane = (dx <= a) & (dy <= b)
        h = np.sqrt(np.maximum(dx - a, 0.0) ** 2 + np.maximum(dy - b, 0.0) ** 2)
        v = np.maximum(Zs[:, None] - c - d, np.maximum(d - Zs[:, None] - c, 0.0))
        dist = np.sqrt(h ** 2 + v ** 2)
        hit = in_plane & (Zs[:, None] <= d + c)
        hit |= in_plane & (Zs[:, None] > d + c) & ((Zs[:, None] - c - d) <= R)
        hit |= (~in_plane) & (dist <= R)
        total += int(hit.any(axis=1).sum())
    return total / n

def prob_ind_approx(X, Y, Z, px, py, d, chunk=1_000_000):
    """独立近似：把各弹命中当作独立事件（会高估）。"""
    n = len(X); cnt = np.zeros(len(px), dtype=np.float64)
    for s in range(0, n, chunk):
        e = min(s + chunk, n)
        Xs = X[s:e]; Ys = Y[s:e]; Zs = Z[s:e]
        dx = np.abs(Xs[:, None] - px[None, :]); dy = np.abs(Ys[:, None] - py[None, :])
        in_plane = (dx <= a) & (dy <= b)
        h = np.sqrt(np.maximum(dx - a, 0.0) ** 2 + np.maximum(dy - b, 0.0) ** 2)
        v = np.maximum(Zs[:, None] - c - d, np.maximum(d - Zs[:, None] - c, 0.0))
        dist = np.sqrt(h ** 2 + v ** 2)
        hit = in_plane & (Zs[:, None] <= d + c)
        hit |= in_plane & (Zs[:, None] > d + c) & ((Zs[:, None] - c - d) <= R)
        hit |= (~in_plane) & (dist <= R)
        cnt += hit.sum(axis=0)
    p_i = cnt / n
    return 1.0 - np.prod(1.0 - p_i)

rng = np.random.default_rng(42)

# ---------- 分层网格搜索：每个朝向角 θ 做完整二维重扫 ----------
d_grid = np.linspace(140.0, 175.0, 25)
del_grid = np.linspace(40.0, 170.0, 27)
thetas = [0.0, 15.0, 30.0, 45.0]
Nc = 500_000
Nf = 2_000_000

t0 = time.time()
Xc, Yc, Zc = sample_XYZ(rng, Nc)
coarse_res = {}
for th in thetas:
    Pmat = np.zeros((len(d_grid), len(del_grid)))
    for i, d in enumerate(d_grid):
        for j, dl in enumerate(del_grid):
            px, py = array_points(dl, th)
            Pmat[i, j] = prob_any_hit(Xc, Yc, Zc, px, py, d)
    coarse_res[th] = Pmat
    i0, j0 = np.unravel_index(np.argmax(Pmat), Pmat.shape)
    print(f"粗扫描 θ={th}°: P={Pmat.max():.4f} at d={d_grid[i0]:.1f}, Δ={del_grid[j0]:.0f}", flush=True)

Xf, Yf, Zf = sample_XYZ(rng, Nf)
fine_res = {}
theta_scan = []
for th in thetas:
    Pmat = coarse_res[th]
    i0, j0 = np.unravel_index(np.argmax(Pmat), Pmat.shape)
    d_lo, d_hi = d_grid[max(i0 - 2, 0)], d_grid[min(i0 + 2, len(d_grid) - 1)]
    dl_lo, dl_hi = del_grid[max(j0 - 2, 0)], del_grid[min(j0 + 2, len(del_grid) - 1)]
    d_fine = np.linspace(d_lo, d_hi, 15)
    dl_fine = np.linspace(dl_lo, dl_hi, 15)
    Pfine = np.zeros((len(d_fine), len(dl_fine)))
    for i, d in enumerate(d_fine):
        for j, dl in enumerate(dl_fine):
            px, py = array_points(dl, th)
            Pfine[i, j] = prob_any_hit(Xf, Yf, Zf, px, py, d)
    i1, j1 = np.unravel_index(np.argmax(Pfine), Pfine.shape)
    fine_res[th] = {"d": d_fine.tolist(), "delta": dl_fine.tolist(), "P": Pfine.tolist()}
    theta_scan.append({"theta": th, "P": float(Pfine.max()),
                       "d": float(d_fine[i1]), "delta": float(dl_fine[j1])})
    print(f"精扫描 θ={th}°: P={Pfine.max():.5f} at d={d_fine[i1]:.2f}, Δ={dl_fine[j1]:.2f}", flush=True)

best = max(theta_scan, key=lambda t: t["P"])
th_opt, d_opt, dl_opt = best["theta"], best["d"], best["delta"]
print(f"全局最优: θ={th_opt:.0f}°, d={d_opt:.2f}, Δ={dl_opt:.2f}", flush=True)

# ---------- 大样本最终验证 ----------
Nv = 12_000_000
Xv, Yv, Zv = sample_XYZ(rng, Nv)
px_opt, py_opt = array_points(dl_opt, th_opt)
P_joint = prob_any_hit(Xv, Yv, Zv, px_opt, py_opt, d_opt)
P_ind = prob_ind_approx(Xv, Yv, Zv, px_opt, py_opt, d_opt)
# 单弹命中率（原点投弹）
px1, py1 = array_points(0.0, 0.0)
p1 = prob_any_hit(Xv, Yv, Zv, px1, py1, d_opt)
print(f"\n最终方案: d*={d_opt:.2f} m, Δ*={dl_opt:.2f} m, θ*={th_opt:.0f}°")
print(f"单弹命中率 p1 = {p1:.5f}")
print(f"至少一枚命中 P_joint = {P_joint:.5f}（大样本 12M）")
print(f"独立近似 P_ind     = {P_ind:.5f}（低估 {P_joint - P_ind:.5f}）")

# ---------- 保存 ----------
res = {
    "coarse": {"d": d_grid.tolist(), "delta": del_grid.tolist(),
               "P": coarse_res[0.0].tolist()},
    "fine": {str(int(t)): v for t, v in fine_res.items()},
    "theta_scan": [{"theta": t["theta"], "P": t["P"], "d": t["d"], "delta": t["delta"]}
                   for t in theta_scan],
    "opt": {"d": d_opt, "delta": dl_opt, "theta_deg": th_opt,
            "P_joint": P_joint, "P_independent_approx": P_ind, "p_single": p1},
}
with open(r"output/q3/result_q3.json", "w", encoding="utf-8") as f:
    json.dump(res, f, ensure_ascii=False, indent=2)
print(f"saved result_q3.json（总耗时 {time.time()-t0:.0f}s）")
