﻿# -*- coding: utf-8 -*-
"""阶段6：生成论文图表（中文标签、彩色、RGB、DPI>=300、字号>=10pt）。
包含：7 张结果图 + 问题分析思维导图 + 模型求解流程图。"""
import json, sys, io
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch, FancyArrowPatch
from PIL import Image
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial Unicode MS"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["font.size"] = 11
plt.rcParams["axes.titlesize"] = 12
plt.rcParams["figure.dpi"] = 100

with open(r"data/parameters.json", encoding="utf-8-sig") as f:
    P = json.load(f)
a, b, c = P["submarine"]["half_length"], P["submarine"]["half_width"], P["submarine"]["half_height"]
R = P["weapon"]["kill_radius"]
sigma = P["errors"]["sigma_xy"]; h0 = P["errors"]["depth_est"]

q1 = json.load(open(r"output/q1/result_q1.json", encoding="utf-8-sig"))
q2 = json.load(open(r"output/q2/result_q2.json", encoding="utf-8-sig"))
q3 = json.load(open(r"output/q3/result_q3.json", encoding="utf-8-sig"))
cd = json.load(open(r"data/chart_data.json", encoding="utf-8-sig"))

def savefig(fig, path):
    fig.savefig(path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    # 统一转为 RGB，避免 RGBA 色深问题
    Image.open(path).convert("RGB").save(path, dpi=(300, 300))  # 保留300dpi元数据
    print("saved", path)

# ============ 结果图1：问题1 命中区域几何示意 ============
fig, ax = plt.subplots(figsize=(7.2, 5.2))
ax.add_patch(Rectangle((-a, -b), 2*a, 2*b, fc="#4472c4", ec="k", alpha=0.55, label="潜艇平面矩形（100 m×20 m）"))
ax.add_patch(Rectangle((-a-R, -b-R), 2*(a+R), 2*(b+R), fc="none", ec="#c00000", lw=2, ls="--", label="定深引信外扩带（R=20 m）"))
xs = np.linspace(-a-R, a+R, 401); ys = np.linspace(-b-R, b+R, 401)
XX, YY = np.meshgrid(xs, ys, indexing="ij")
hh = np.sqrt(np.maximum(np.abs(XX)-a, 0)**2 + np.maximum(np.abs(YY)-b, 0)**2)
band = (hh <= R) & (~((np.abs(XX)<=a) & (np.abs(YY)<=b)))
ax.contourf(XX, YY, band.astype(float), levels=[0.5, 1.5], colors=["#ffd966"], alpha=0.85)
ax.add_patch(Rectangle((-a, -b), 2*a, 2*b, fc="#4472c4", ec="k", alpha=0.55))
ax.plot(0, 0, "*", ms=16, color="#c00000", label="最优投弹落点 (0,0)")
ax.axhline(0, color="gray", lw=0.8); ax.axvline(0, color="gray", lw=0.8)
ax.set_xlim(-a-R-5, a+R+5); ax.set_ylim(-b-R-5, b+R+5)
ax.set_xlabel("X / m（正东）"); ax.set_ylabel("Y / m（正南）")
ax.set_aspect("equal")
ax.legend(loc="upper right", fontsize=10)
fig.text(0.5, 0.005, "命中区域 = 触发引信区（平面内）∪ 定深引信区（平面外、水平距离≤20 m）",
         ha="center", fontsize=10, color="#444444")
savefig(fig, r"output/q1/fig_q1_region.png")

# ============ 结果图2：问题1 引爆深度敏感性 ============
fig, ax = plt.subplots(figsize=(7.0, 5.0))
fig.subplots_adjust(bottom=0.25)
d = np.array(q1["d_sensitivity"]["d"]); p = np.array(q1["d_sensitivity"]["p"])
ax.plot(d, p, "-o", color="#2e75b6", lw=1.8, ms=4, label="命中概率 P(d)")
ax.axvspan(137.5, 162.5, color="#ffd966", alpha=0.4, label="最优深度区间 [137.5, 162.5] m")
ax.axhline(q1["P_max_analytic"], color="#c00000", ls="--", lw=1.4, label=f"最大命中概率 {q1['P_max_analytic']:.4f}")
ax.axvline(137.5, color="#c00000", lw=1.0, ls=":")
ax.set_xlabel("定深引信引爆深度 d / m"); ax.set_ylabel("命中概率 P")
ax.legend(fontsize=10); ax.grid(alpha=0.3)
fig.text(0.5, 0.005, "当 d 位于潜艇上表面 137.5 m 与下表面 162.5 m 之间时，命中概率达到最大值且与 d 无关。",
         ha="center", fontsize=10, color="#444444")
savefig(fig, r"output/q1/fig_q1_d.png")

# ============ 结果图3：问题1 落点偏移敏感性 ============
fig, ax = plt.subplots(figsize=(7.0, 5.0))
fig.subplots_adjust(bottom=0.25)
x0 = np.array(q1["x0_sensitivity"]["x0"]); px = np.array(q1["x0_sensitivity"]["p"])
ax.plot(x0, px, "-s", color="#2e75b6", lw=1.8, ms=5)
ax.set_xlabel("投弹落点 X 方向偏移 $x_0$ / m"); ax.set_ylabel("命中概率 P")
ax.grid(alpha=0.3)
fig.text(0.5, 0.005, "命中概率在潜艇中心投影处取最大值，随落点偏移单调下降。",
         ha="center", fontsize=10, color="#444444")
savefig(fig, r"output/q1/fig_q1_x0.png")

# ============ 结果图4：问题2 P(d) 曲线与成分分解（左右双栏） ============
fig, (ax_curve, ax_bar) = plt.subplots(1, 2, figsize=(9.0, 4.6), gridspec_kw={"width_ratios": [1.8, 1]})
fig.subplots_adjust(bottom=0.24, wspace=0.38)
# 左栏：P(d) 曲线
d2 = np.array(cd["q2_P_curve"]["d"]); p2 = np.array(cd["q2_P_curve"]["P"])
ax_curve.plot(d2, p2, "-", color="#2e75b6", lw=2.0, label="总命中概率 P(d)")
d_star = q2["d_star"]
ax_curve.axvline(d_star, color="#c00000", ls="--", lw=1.5, label=f"最优深度 d*={d_star:.1f} m")
ax_curve.plot([d_star], [q2["P_star_mc"]], "*", ms=14, color="#c00000")
ax_curve.annotate(f"P* = {q2['P_star_mc']:.4f}", xy=(d_star, q2["P_star_mc"]),
            xytext=(d_star+9, q2["P_star_mc"]+0.004), fontsize=10,
            arrowprops=dict(arrowstyle="->", color="#c00000"))
ax_curve.set_xlabel("定深引信引爆深度 d / m"); ax_curve.set_ylabel("命中概率 P")
ax_curve.grid(alpha=0.3); ax_curve.legend(fontsize=9, loc="upper right")
# 右栏：命中概率成分柱状图（d=d* 处）
comp = cd["q2_P_curve"]["components"]
bars = ax_bar.bar(["E1\n(平面内)", "E2\n(平面内)", "E3\n(平面外)"],
       [comp["E1"], comp["E2"], comp["E3"]], color=["#4472c4", "#ed7d31", "#ffc000"],
       width=0.55, alpha=0.9)
for i, k in enumerate(["E1", "E2", "E3"]):
    ax_bar.text(i, comp[k]+0.0006, f"{comp[k]:.4f}", ha="center", fontsize=10)
ax_bar.set_ylabel("命中概率 P"); ax_bar.set_title("d=d* 处各成分贡献", fontsize=10)
ax_bar.grid(axis="y", alpha=0.3)
fig.text(0.5, 0.02, "E3（平面外定深引爆）贡献最大，是决定最优深度与命中率的关键成分。",
         ha="center", fontsize=10, color="#444444")
savefig(fig, r"output/q2/fig_q2_Pd.png")

# ============ 结果图5：问题3 (d,Δ) 热力图（θ=45°） ============
fig, ax = plt.subplots(figsize=(7.2, 5.8))
fig.subplots_adjust(bottom=0.20)
P45 = np.array(cd["q3_fine45"]["P"])
d4 = np.array(cd["q3_fine45"]["d"]); dl4 = np.array(cd["q3_fine45"]["delta"])
im = ax.imshow(P45.T, origin="lower", aspect="auto", extent=[d4[0], d4[-1], dl4[0], dl4[-1]],
               cmap="YlOrRd")
d_opt, dl_opt = q3["opt"]["d"], q3["opt"]["delta"]
ax.plot(d_opt, dl_opt, "k*", ms=16, label=f"最优 (d*={d_opt:.1f}, Δ*={dl_opt:.0f})")
cb = fig.colorbar(im, ax=ax, label="至少一枚命中概率")
ax.set_xlabel("定深引信引爆深度 d / m"); ax.set_ylabel("阵列平面间隔 Δ / m")
ax.legend(fontsize=10, loc="upper left")
fig.text(0.5, 0.005, "命中概率对 d 较敏感、对 Δ 较为平缓，最优间隔约 85 m。",
         ha="center", fontsize=10, color="#444444")
savefig(fig, r"output/q3/fig_q3_heatmap.png")

# ============ 结果图6：问题3 阵列朝向敏感性 ============
fig, ax = plt.subplots(figsize=(7.0, 5.0))
fig.subplots_adjust(bottom=0.25)
th = np.array(cd["q3_theta_curve"]["theta"]); pt = np.array(cd["q3_theta_curve"]["P"])
ax.plot(th, pt, "-o", color="#2e75b6", lw=1.8, ms=5)
ax.plot([45], [pt[-1]], "*", ms=15, color="#c00000")
ax.annotate(f"θ*=45°, P={pt[-1]:.4f}", xy=(45, pt[-1]), xytext=(24, pt[-1]-0.02),
            fontsize=10, arrowprops=dict(arrowstyle="->", color="#c00000"))
ax.set_xlabel("阵列朝向角 θ / °"); ax.set_ylabel("至少一枚命中概率")
ax.grid(alpha=0.3)
fig.text(0.5, 0.005, "由于潜艇长轴与短轴尺度差异显著，阵列旋转 45° 可使命中概率提升约 8 个百分点。",
         ha="center", fontsize=10, color="#444444")
savefig(fig, r"output/q3/fig_q3_theta.png")

# ============ 结果图7：问题3 最优阵列布局示意 ============
fig, ax = plt.subplots(figsize=(7.2, 5.6))
d3, dl3, th3 = q3["opt"]["d"], q3["opt"]["delta"], q3["opt"]["theta_deg"]
thr = np.deg2rad(th3)
off = np.array([-dl3, 0.0, dl3])
for i in off:
    for j in off:
        x = i*np.cos(thr) - j*np.sin(thr); y = i*np.sin(thr) + j*np.cos(thr)
        ax.plot(x, y, "o", ms=8, color="#c00000", zorder=5)
ax.add_patch(Rectangle((-a, -b), 2*a, 2*b, fc="#4472c4", ec="k", alpha=0.5, zorder=4))
ax.add_patch(Rectangle((-a-R, -b-R), 2*(a+R), 2*(b+R), fc="none", ec="#2e75b6", ls="--", lw=1.5))
ax.plot(0, 0, "k+", ms=12)
ax.set_xlim(-160, 160); ax.set_ylim(-160, 160)
ax.set_xlabel("X / m（正东）"); ax.set_ylabel("Y / m（正南）")
ax.set_aspect("equal")
fig.text(0.5, 0.005, "红色圆点为 9 枚深弹落点，蓝色矩形为潜艇，虚线框为单枚深弹的平面杀伤外扩带。",
         ha="center", fontsize=10, color="#444444")
savefig(fig, r"output/q3/fig_q3_scheme.png")

# ============ 图1：问题分析思维导图 ============
def draw_mindmap():
    BG = "#f5f8fc"
    fig, ax = plt.subplots(figsize=(13.6, 8.6))
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(BG)
    ax.set_xlim(0, 13.6); ax.set_ylim(0.3, 8.6)
    ax.set_aspect("equal")
    ax.axis("off")

    def box(x, y, w, h, text, fc, ec, fs=11, tc="black", bold=False, lw=1.4, rounded=False):
        style = "round,pad=0.02,rounding_size=0.10" if rounded else "square,pad=0.02"
        ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle=style,
                                    fc=fc, ec=ec, lw=lw, zorder=3))
        ax.text(x, y, text, ha="center", va="center", fontsize=fs, color=tc,
                zorder=4, linespacing=1.35, fontweight="bold" if bold else "normal")

    def link(x1, y1, x2, y2, color="#4472c4", lw=1.6):
        ax.plot([x1, x2], [y1, y2], color=color, lw=lw, zorder=1, solid_capstyle="round")

    cx, cy = 1.5, 4.45
    box(cx, cy, 2.7, 1.55, "反潜航空深弹\n命中概率问题", "#1f4e79", "#1f4e79",
        fs=13.5, tc="white", bold=True, rounded=True)
    spine_x = 3.15
    link(cx + 1.35, cy, spine_x, cy, color="#2e75b6", lw=2.2)

    branches = [
        ("问题一：单枚深弹\n深度定位无误差", 7.15,
         ["命中判定：平面内触发引信\n＋平面外定深引信", "最优落点：定位投影原点",
          "最优定深：上、下表面之间\n（25 m 稳健平台）", "验证：数值积分与蒙特卡洛\n结果一致"]),
        ("问题二：单枚深弹\n三维定位均有误差", 5.35,
         ["深度误差：单边截尾\n正态分布刻画", "概率模型：平面内＋平面外\n概率积分表达式",
          "求解：一维精确寻优\n确定唯一最优定深", "验证：大规模蒙特卡洛\n交叉验证"]),
        ("问题三：9 枚深弹\n3×3 阵列投弹", 3.55,
         ["相关性：同一潜艇位置下\n多弹命中条件相关", "优化变量：定深 d、\n间隔 Δ、朝向角 θ",
          "求解：分层网格搜索＋\n大样本蒙特卡洛", "对照：独立近似明显\n低估联合概率"]),
        ("方法主线\n解析推导＋数值验证", 1.75,
         ["概率建模：以定位误差\n分布刻画命中事件", "解析推导：给出闭式或\n积分表达式并逐式讲解",
          "数值求解：自适应数值\n积分与最优化", "交叉验证：理论值与模拟\n值相互印证"]),
    ]
    bx, lx1, lx2 = 5.3, 8.8, 11.8
    for label, by, leaves in branches:
        link(spine_x, by, bx - 1.75, by, color="#2e75b6", lw=1.8)
        box(bx, by, 3.3, 1.0, label, "#dae3f3", "#2e75b6", fs=11.5, bold=True)
        rows = [(by + 0.48, leaves[0], leaves[1]), (by - 0.48, leaves[2], leaves[3])]
        for ly, leaf_l, leaf_r in rows:
            for lx, leaf in ((lx1, leaf_l), (lx2, leaf_r)):
                link(bx + 1.65, by, lx - 1.4, ly, color="#8eaadb", lw=1.2)
                box(lx, ly, 2.8, 0.7, leaf, "#ffffff", "#8eaadb", fs=10)
    savefig(fig, r"output/mindmap(问题分析思维导图).png")

# ============ 图2：模型求解流程图 ============
def draw_flowchart():
    BG = "#f5f8fc"
    fig, ax = plt.subplots(figsize=(8.8, 12.6))
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(BG)
    ax.set_xlim(0, 8.8); ax.set_ylim(0, 12.6)
    ax.axis("off")

    def box(x, y, w, h, text, fc, ec, fs=10.5, bold=False, rounded=False):
        style = "round,pad=0.02,rounding_size=0.12" if rounded else "square,pad=0.02"
        ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle=style,
                                    fc=fc, ec=ec, lw=1.4, zorder=3))
        ax.text(x, y, text, ha="center", va="center", fontsize=fs,
                color="#1f3864", zorder=4, linespacing=1.35,
                fontweight="bold" if bold else "normal")

    def arrow(y_from, y_to):
        ax.add_patch(FancyArrowPatch((4.4, y_from - 0.525), (4.4, y_to + 0.525),
                                     arrowstyle="-|>", mutation_scale=16,
                                     color="#2e75b6", lw=1.8, zorder=2))

    BLUE, ORANGE, GREEN = "#dae3f3", "#fbe5d6", "#e2efda"
    items = [
        ("开始：输入参数\nσ=120 m、σ_z=40 m、R=20 m、潜艇 100×20×25 m", GREEN),
        ("问题一建模：双引信命中判定\n（平面内触发引信＋平面外定深引信）", BLUE),
        ("问题一求解：数值积分与蒙特卡洛验证\n→ 落点取原点、定深取上下表面之间", ORANGE),
        ("问题二建模：深度按单边截尾正态刻画\n→ 平面内＋平面外概率积分表达式", BLUE),
        ("问题二求解：一维精确寻优确定 d*\n→ 蒙特卡洛交叉验证", ORANGE),
        ("问题三建模：3×3 阵列条件并集模型\n→ “至少一枚命中”多重积分", BLUE),
        ("问题三求解：分层网格搜索优化\n（d、Δ、θ）＋大样本蒙特卡洛验证", ORANGE),
        ("结束：输出三问最优方案\n与灵敏度分析结论", GREEN),
    ]
    ys = np.linspace(11.9, 1.2, len(items))
    for (text, fc), y in zip(items, ys):
        box(4.4, y, 6.8, 1.05, text, fc, "#1f4e79" if text.startswith(("开始", "结束")) else "#2e75b6",
            fs=10.5, bold=text.startswith(("开始", "结束")), rounded=text.startswith(("开始", "结束")))
    for i in range(len(items) - 1):
        arrow(ys[i], ys[i + 1])
    savefig(fig, r"output/flowchart(模型求解流程图).png")

draw_mindmap()
draw_flowchart()

print("all charts done")
