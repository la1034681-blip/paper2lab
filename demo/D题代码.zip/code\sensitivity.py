﻿# -*- coding: utf-8 -*-
"""灵敏度分析与补充统计：统一生成论文表5（Δ灵敏度）、表7（σ/R灵敏度）、
表8（σ_z灵敏度）、表9（收敛性）、4×4方阵扩展与多弹相关性统计。
运行方式：python code/sensitivity.py（在项目根目录下）。
积分采用 48 点高斯-勒让德求积，与 scipy 自适应积分一致（偏差<1e-6）。
"""
import json, sys, io, time
import numpy as np
from scipy import stats, optimize
from numpy.polynomial.legendre import leggauss
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

with open(r"data/parameters.json", encoding="utf-8-sig") as f:
    P = json.load(f)
a, b, c = P["submarine"]["half_length"], P["submarine"]["half_width"], P["submarine"]["half_height"]
R0 = P["weapon"]["kill_radius"]
sigma0 = P["errors"]["sigma_xy"]
h0 = P["errors"]["depth_est"]
sigz0 = P["errors"]["sigma_z"]
l = P["errors"]["min_depth"]

phi = stats.norm.pdf; Phi = stats.norm.cdf
xg, wg = leggauss(48)

def quad2_rect(f, x_lo, x_hi, y_lo, y_hi):
    x = 0.5 * (x_hi - x_lo) * xg + 0.5 * (x_hi + x_lo)
    y = 0.5 * (y_hi - y_lo) * xg + 0.5 * (y_hi + y_lo)
    XX, YY = np.meshgrid(x, y)
    fv = f(XX, YY)
    return 0.25 * (x_hi - x_lo) * (y_hi - y_lo) * np.sum(fv * wg[None, :] * wg[:, None])

# ============ 表7：问题一 σ/R 灵敏度（精确积分） ============
def Pmax_q1(sigma_v, R_v):
    # 按区域分解避免积分边界不连续：P(B)=B1+B2-B0+B3（角区用极坐标光滑积分）
    A1 = 2 * Phi(a / sigma_v) - 1; B1 = 2 * Phi(b / sigma_v) - 1
    AB = 2 * Phi((a + R_v) / sigma_v) - 1; BB = 2 * Phi((b + R_v) / sigma_v) - 1
    pB1 = A1 * BB; pB2 = AB * B1; pB0 = A1 * B1
    r = 0.5 * R_v * xg + 0.5 * R_v
    th = 0.5 * (np.pi / 2) * xg + 0.5 * (np.pi / 2)
    RR, TH = np.meshgrid(r, th)
    X = a + RR * np.cos(TH); Y = b + RR * np.sin(TH)
    f = phi(X / sigma_v) / sigma_v * phi(Y / sigma_v) / sigma_v * RR
    pB3_1q = 0.25 * R_v * (np.pi / 2) * np.sum(f * wg[None, :] * wg[:, None])
    return pB1 + pB2 - pB0 + 4.0 * pB3_1q

tbl7 = []
for s in (60, 80, 100, 120, 140, 160):
    tbl7.append({"param": "sigma", "value": s, "P": Pmax_q1(s, R0)})
for r in (15, 20, 25, 30):
    tbl7.append({"param": "R", "value": r, "P": Pmax_q1(sigma0, r)})

# ============ 表8：问题二 σ_z 灵敏度（精确积分 + 一维寻优） ============
def F_Z_g(z, sz):
    z = np.asarray(z, dtype=float)
    den = 1.0 - Phi((l - h0) / sz)
    return np.where(z <= l, 0.0, (Phi((z - h0) / sz) - Phi((l - h0) / sz)) / den)

def P_integral_q2(d, sz):
    def fx(x): return phi(x / sigma0) / sigma0
    def fy(y): return phi(y / sigma0) / sigma0
    term1 = (2 * Phi(a / sigma0) - 1) * (2 * Phi(b / sigma0) - 1) * F_Z_g(d + c + R0, sz)
    def fB1(X, Y):
        s = np.sqrt(R0 ** 2 - (Y - b) ** 2)
        return (F_Z_g(d + c + s, sz) - F_Z_g(d - c - s, sz)) * fx(X) * fy(Y)
    IB1 = quad2_rect(fB1, 0.0, a, b, b + R0)
    def fB2(X, Y):
        s = np.sqrt(R0 ** 2 - (X - a) ** 2)
        return (F_Z_g(d + c + s, sz) - F_Z_g(d - c - s, sz)) * fx(X) * fy(Y)
    IB2 = quad2_rect(fB2, a, a + R0, 0.0, b)
    r = 0.5 * R0 * xg + 0.5 * R0
    th = 0.5 * (np.pi / 2) * xg + 0.5 * (np.pi / 2)
    RR, TH = np.meshgrid(r, th)
    X = a + RR * np.cos(TH); Y = b + RR * np.sin(TH)
    s = np.sqrt(R0 ** 2 - RR ** 2)
    fB3 = (F_Z_g(d + c + s, sz) - F_Z_g(d - c - s, sz)) * fx(X) * fy(Y) * RR
    IB3 = 0.25 * R0 * (np.pi / 2) * np.sum(fB3 * wg[None, :] * wg[:, None])
    return term1 + 4.0 * (IB1 + IB2 + IB3)

tbl8 = []
for sz in (20, 30, 40, 50, 60):
    opt = optimize.minimize_scalar(lambda d: -P_integral_q2(d, sz), bounds=(100.0, 185.0),
                                   method="bounded", options={"xatol": 1e-4})
    tbl8.append({"sigz": sz, "d_star": float(opt.x), "P_star": float(-opt.fun)})

# ============ 表9：问题一收敛性（d=150 m 原点投弹） ============
def hit_q1(X, Y, d):
    dx = np.abs(X); dy = np.abs(Y)
    in_plane = (dx <= a) & (dy <= b)
    h = np.sqrt(np.maximum(dx - a, 0) ** 2 + np.maximum(dy - b, 0) ** 2)
    v = np.maximum((h0 - c) - d, np.maximum(d - (h0 + c), 0.0))
    dist = np.sqrt(h ** 2 + v ** 2)
    hit = in_plane & (d >= (h0 - c))
    hit |= in_plane & (d < (h0 - c)) & (((h0 - c) - d) <= R0)
    hit |= (~in_plane) & (dist <= R0)
    return hit

P_analytic = 0.0837350141373228
tbl9 = []
rng9 = np.random.default_rng(2026)
for N in (10_000, 100_000, 1_000_000, 8_000_000):
    X = rng9.normal(0.0, sigma0, N); Y = rng9.normal(0.0, sigma0, N)
    freq = hit_q1(X, Y, h0).mean()
    se = np.sqrt(freq * (1 - freq) / N)
    tbl9.append({"N": N, "freq": float(freq), "dev": float(freq - P_analytic), "se": float(se)})

# ============ 表5：问题三 Δ 灵敏度（θ=45°，d=d*） ============
q3 = json.load(open(r"output/q3/result_q3.json", encoding="utf-8"))
d_opt = q3["opt"]["d"]; dl_opt = q3["opt"]["delta"]; th_opt = q3["opt"]["theta_deg"]
denom = 1.0 - Phi((l - h0) / sigz0)

def sample_XYZ3(rng, N):
    X = rng.normal(0.0, sigma0, N); Y = rng.normal(0.0, sigma0, N)
    u = rng.uniform(0.0, 1.0, N)
    Z = h0 + sigz0 * stats.norm.ppf(Phi((l - h0) / sigz0) + u * denom)
    return X, Y, Z

def array_points(delta, theta_deg):
    th = np.deg2rad(theta_deg); off = np.array([-delta, 0.0, delta])
    xs, ys = np.meshgrid(off, off)
    return (xs * np.cos(th) - ys * np.sin(th)).ravel(), (xs * np.sin(th) + ys * np.cos(th)).ravel()

def prob_any_hit(X, Y, Z, px, py, d, chunk=1_000_000):
    n = len(X); total = 0
    for s in range(0, n, chunk):
        e = min(s + chunk, n)
        Xs = X[s:e]; Ys = Y[s:e]; Zs = Z[s:e]
        dx = np.abs(Xs[:, None] - px[None, :]); dy = np.abs(Ys[:, None] - py[None, :])
        in_plane = (dx <= a) & (dy <= b)
        h = np.sqrt(np.maximum(dx - a, 0.0) ** 2 + np.maximum(dy - b, 0.0) ** 2)
        v = np.maximum(Zs[:, None] - c - d, np.maximum(d - Zs[:, None] - c, 0.0))
        dist = np.sqrt(h ** 2 + v ** 2)
        hit = in_plane & (Zs[:, None] <= d + c)
        hit |= in_plane & (Zs[:, None] > d + c) & ((Zs[:, None] - c - d) <= R0)
        hit |= (~in_plane) & (dist <= R0)
        total += int(hit.any(axis=1).sum())
    return total / n

rng3 = np.random.default_rng(7)
N3 = 2_000_000
X3, Y3, Z3 = sample_XYZ3(rng3, N3)
deltas = [50.0, 70.0, dl_opt, 110.0, 130.0, 150.0]
tbl5 = []
for dl in deltas:
    px, py = array_points(dl, th_opt)
    pv = prob_any_hit(X3, Y3, Z3, px, py, d_opt)
    tbl5.append({"delta": dl, "P": float(pv)})
P_opt_dl = tbl5[[round(t["delta"], 2) for t in tbl5].index(round(dl_opt, 2))]["P"]

# ============ 4×4 方阵扩展（3M 样本） ============
def array_pts_n(n, delta, theta_deg):
    th = np.deg2rad(theta_deg)
    k = int(round(n ** 0.5))
    off = np.linspace(-(k - 1) / 2, (k - 1) / 2, k) * delta
    xs, ys = np.meshgrid(off, off)
    return (xs * np.cos(th) - ys * np.sin(th)).ravel(), (xs * np.sin(th) + ys * np.cos(th)).ravel()

N4 = 3_000_000
X4, Y4, Z4 = sample_XYZ3(rng3, N4)
p1x = prob_any_hit(X4, Y4, Z4, *array_pts_n(1, dl_opt, th_opt), d_opt)
p33 = prob_any_hit(X4, Y4, Z4, *array_pts_n(9, dl_opt, th_opt), d_opt)
p44 = prob_any_hit(X4, Y4, Z4, *array_pts_n(16, dl_opt, th_opt), d_opt)

# ============ 多弹相关性统计（36 对命中事件） ============
def hit_matrix(X, Y, Z, px, py, d, chunk=1_000_000):
    n = len(X); cnt = np.zeros((n, len(px)), dtype=np.int8)
    for s in range(0, n, chunk):
        e = min(s + chunk, n)
        Xs = X[s:e]; Ys = Y[s:e]; Zs = Z[s:e]
        dx = np.abs(Xs[:, None] - px[None, :]); dy = np.abs(Ys[:, None] - py[None, :])
        in_plane = (dx <= a) & (dy <= b)
        h = np.sqrt(np.maximum(dx - a, 0.0) ** 2 + np.maximum(dy - b, 0.0) ** 2)
        v = np.maximum(Zs[:, None] - c - d, np.maximum(d - Zs[:, None] - c, 0.0))
        dist = np.sqrt(h ** 2 + v ** 2)
        hit = in_plane & (Zs[:, None] <= d + c)
        hit |= in_plane & (Zs[:, None] > d + c) & ((Zs[:, None] - c - d) <= R0)
        hit |= (~in_plane) & (dist <= R0)
        cnt[s:e] = hit.astype(np.int8)
    return cnt

rngc = np.random.default_rng(11)
Nc = 2_000_000
Xc, Yc, Zc = sample_XYZ3(rngc, Nc)
pxc, pyc = array_points(dl_opt, th_opt)
H = hit_matrix(Xc, Yc, Zc, pxc, pyc, d_opt).astype(np.float64)
C = np.corrcoef(H.T)
rs = [C[i, j] for i in range(9) for j in range(i + 1, 9)]
n_neg = sum(1 for r in rs if r < 0)
mean_r = float(np.mean(rs))

# ============ 保存与输出 ============
res = {
    "table5_delta_sensitivity": [{"delta": t["delta"], "P": t["P"]} for t in tbl5],
    "table7_sigmaR": [{"param": t["param"], "value": t["value"], "P": t["P"]} for t in tbl7],
    "table8_sigz": [{"sigz": t["sigz"], "d_star": t["d_star"], "P_star": t["P_star"]} for t in tbl8],
    "table9_convergence": [{"N": t["N"], "freq": t["freq"], "dev": t["dev"], "se": t["se"]} for t in tbl9],
    "opt": {"d": d_opt, "delta": dl_opt, "theta_deg": th_opt},
    "array_ext": {"single": float(p1x), "p33": float(p33), "p44": float(p44),
                  "p33_to_p44_gain": float((p44 - p33) / p33)},
    "correlation": {"pairs": 36, "negative": n_neg, "mean_r": mean_r},
}
with open(r"output/q3/sensitivity_results.json", "w", encoding="utf-8") as f:
    json.dump(res, f, ensure_ascii=False, indent=2)

print("=== 表5 Δ 灵敏度（θ=45°, d=%.2f）===" % d_opt)
for t in tbl5:
    print(f"  Δ={t['delta']:.2f}: P={t['P']:.4f}")
print("=== 表7 σ/R 灵敏度 ===")
for t in tbl7:
    print(f"  {t['param']}={t['value']}: P*={t['P']:.4f}")
print("=== 表8 σ_z 灵敏度 ===")
for t in tbl8:
    print(f"  σ_z={t['sigz']}: d*={t['d_star']:.2f}, P*={t['P_star']:.4f}")
print("=== 表9 收敛性 ===")
for t in tbl9:
    print(f"  N={t['N']:.0e}: freq={t['freq']:.4f}, dev={t['dev']:.1e}, se={t['se']:.1e}")
print(f"=== 4×4 扩展 === 单弹={p1x:.4f}, 3×3={p33:.4f}, 4×4={p44:.4f}, 增益={(p44-p33)/p33*100:.1f}%")
print(f"=== 相关性 === {n_neg}/36 对负相关, 平均 r={mean_r:.3f}")
print("saved output/sensitivity_results.json")
