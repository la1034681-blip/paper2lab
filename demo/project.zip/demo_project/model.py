"""Model definition."""
import torch.nn as nn


def build_resnet18(dropout=0.1):
    return nn.Sequential(nn.Flatten(), nn.Linear(3072, 10), nn.Dropout(dropout))
