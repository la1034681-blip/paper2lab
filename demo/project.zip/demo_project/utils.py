"""Training utilities."""


def train_one_epoch(model, loader, optimizer):
    for x, y in loader:
        optimizer.zero_grad()
        loss = model(x).sum()
        loss.backward()
        optimizer.step()
