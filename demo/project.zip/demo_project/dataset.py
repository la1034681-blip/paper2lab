"""Dataset loading helpers."""

DATASET_VERSION = "v2.0"


def load_dataset(name, version=DATASET_VERSION):
    print(f"loading {name} {version}")
    return []
