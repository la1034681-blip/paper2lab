"""Demo training script (受控样例, 故意埋了 3 个问题)."""
import argparse

import torch
import torch.nn as nn
from torch.utils.data import DataLoader


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lr", type=float, default=0.001)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=100)
    return parser.parse_args()


def main():
    args = parse_args()
    lr = 0.001  # 论文声明 1e-4, 这里是 1e-3 (问题1: 差 10 倍)
    batch_size = 32
    epochs = 100
    weight_decay = 5e-4
    dropout = 0.1

    dataset = load_dataset("CIFAR-10", version="v2.0")  # 问题3: 论文是 v2.1
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

    model = build_resnet18(dropout=dropout)
    # 问题2: 论文声明 seed 固定为 42, 但代码里没有 torch.manual_seed
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)

    for epoch in range(epochs):
        train_one_epoch(model, loader, optimizer)
        scheduler.step()


if __name__ == "__main__":
    main()
