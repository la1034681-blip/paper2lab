# -*- coding: utf-8 -*-
LEARNING_RATE = 1e-4
BATCH_SIZE = 32
EPOCHS = 100
DROPOUT = 0.3
import torch
torch.manual_seed(7)
