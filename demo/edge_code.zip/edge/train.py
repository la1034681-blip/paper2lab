# -*- coding: utf-8 -*-
LEARNING_RATE = 0.001
BATCH_SIZE = 32
EPOCHS = 100
optimizer = "Adam"
import torch
torch.manual_seed(0)
