def train(
    lr=1e-4
    print("this file has a syntax error")
