﻿# -*- coding: utf-8 -*-
weight_decay = 0.0005
